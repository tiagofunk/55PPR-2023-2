package observer2;

public interface Observador {

	String receberMensagem(String mensagem);
	
}
