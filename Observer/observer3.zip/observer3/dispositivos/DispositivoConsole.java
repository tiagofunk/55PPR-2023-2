package observer3.dispositivos;

public class DispositivoConsole {

	
}
